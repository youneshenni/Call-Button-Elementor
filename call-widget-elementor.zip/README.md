# Elementor Call Widget

This plugin installs a new widget to Elementor called "Call Widget", it allows you to create a call button that's clickable on mobile devices (It allows them to directly dial the number you have specified in the widget configuration)
