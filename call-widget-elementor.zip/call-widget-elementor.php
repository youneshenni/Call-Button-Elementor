<?php

/**
 * Plugin Name: Call Button Widget for Elementor
 * Description: Auto embed any embbedable content from external URLs into Elementor.
 * Plugin URI:  https://github.com/youneshenni/Call-Button-Elementor
 * Version:     1.0.0
 * Author:      Younes Henni
 * Author URI:  https://github.com/youneshenni/
 * Text Domain: call-widget-elementor
 *
 * Elementor tested up to: 3.5.0
 * Elementor Pro tested up to: 3.5.0
 * 
 * Call Button Widget for Elementor is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Call Button Widget for Elementor is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Call Button Widget for Elementor. If not, see {URI to Plugin License}.

 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Register Call Widget.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
function register_call_widget($widgets_manager)
{

    require_once(__DIR__ . '/widgets/call-widget.php');

    $widgets_manager->register(new \Elementor_Call_Widget());
}
add_action('elementor/widgets/register', 'register_call_widget');
