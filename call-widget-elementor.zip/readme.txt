=== Call Widget for Elementor ===
Contributors: youneshenni
Donate link: -
Tags: call, button, elementor, phone, tel, telephone
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
 
This plugin installs a new widget to Elementor called "Call Widget", it allows you to create a call button that's clickable on mobile devices (It allows them to directly dial the number you have specified in the widget configuration)
